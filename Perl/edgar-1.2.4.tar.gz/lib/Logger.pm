
package Logger;
use strict;
use Symbol;
use Benchmark;

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	$self->{'PID'} = undef;
	$self->{'CURRENT'} = undef;
	$self->{'DO-LOGGING'} = undef;
	$self->{'LOGFILE-HANDLE'} = gensym();
	%{$self->{'INFO'}} = ();
	%{$self->{'TAKEN'}} = ();
	bless $self, $class;
	return $self;
}

sub reInit {
	my $self = shift;
	$self->{'CURRENT'} = undef;
	$self->{'FILE-NAME'} = undef;
	%{$self->{'INFO'}} = ();
	%{$self->{'TAKEN'}} = ();

	if ($self->{'DO-LOGGING'}) {
		my $handle = $self->{'LOGFILE-HANDLE'};
		print $handle "\n";
		print $handle "### re-initilize ###\n";
		print $handle "\n";
	}
}

#######################################
## subs that write to a log file
#######################################
sub logDateTime {
	my $self = shift;

	return if (!$self->{'DO-LOGGING'});

	my $handle = $self->{'LOGFILE-HANDLE'};
	my $date;
	chomp($date = `date`);
	print $handle "#"x70;
	print $handle "\n## logging started on [$date]\n";	
	print $handle "#"x70;
	print $handle "\n\n";
}

sub logFileInfo {
	my $self = shift;
	my %params = @_;

	return if (!$self->{'DO-LOGGING'});

	my $file_name = $params{'-file-name'};
	my $accno = $params{'-accno'};
	my $type = $params{'-type'};

	my $handle = $self->{'LOGFILE-HANDLE'};
	print $handle "File Name : $file_name\n" if $file_name;
	print $handle "Account Number : $accno\n" if $accno;
	print $handle "File Type : $type\n" if $type;

	# flush the buffer, make sure this gets written
	close $handle;
	&openFile($self->{'LOGFILE-HANDLE'}, $self->{'FILE-NAME'});
}
	

sub shutdownLogger {	
	my $self = shift;
	my $handle = $self->{'LOGFILE-HANDLE'};
	my($date);

	return if (!$self->{'DO-LOGGING'});

	chomp($date = `date`);

	print $handle "\n\n";
	print $handle "#"x70;
	print $handle "\n## logging stopped on [$date]\n";	
	print $handle "#"x70;
	print $handle "\n";

	close $handle;
}

sub makepath {
	my $path = shift;
	my $mode = shift;
	my ($newpath, $dir);

        # assumes '/' as path delimiter
	foreach $dir (split(/\//, $path)) {
		$newpath .= "$dir/";
		if (! -d $newpath) {
			mkdir($newpath, $mode);
		}
	}
}

sub setupLogger {
	my $self = shift;
	my %params = @_;

	my $base_dir = $params{'-base-dir'};
	my $base_filename = $params{'-base-filename'};
	my $do_logging = $params{'-do-logging'};

	$self->{'DO-LOGGING'} = $do_logging;
	return if (!$do_logging);

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
	$year += 1900;
	$mon = sprintf("%02d", ++$mon); 
	$mday = sprintf("%02d", $mday); 
	$base_dir .= "/".$year."-".$mon."-".$mday;
	&makepath($base_dir, 0775);

	$self->{'FILE-NAME'} = "$base_dir/$base_filename";

	&openFile($self->{'LOGFILE-HANDLE'}, $self->{'FILE-NAME'});
}

sub openFile {
	my $handle = shift;
	my $filename = shift;

	if (-e "$filename") {
		if (! open ($handle, ">>$filename")) {
			warn "can not append to file [$filename]: $!";
		}
	} else {
		if (! open ($handle, ">$filename")) {
			warn "can not create file [$filename]: $!"
	        }
	}
}

sub writeMessage {
	my $self = shift;
	my %params = @_;
	my $message = $params{'-message'};
	my $handle = $self->{'LOGFILE-HANDLE'};

	return if (!$self->{'DO-LOGGING'});

	print $handle "\n";
	print $handle "################### MESSAGE ########################\n";
        print $handle "## $message\n";
	print $handle "####################################################\n";
 	print $handle "\n";
}

	    
sub outputLogger {
	my $self = shift;
	my $handle = $self->{'LOGFILE-HANDLE'};
	my ($type_key, $data_key);

	return if (!$self->{'DO-LOGGING'});

	print $handle "#### stored values ###\n";
	foreach $type_key (sort keys %{$self->{'INFO'}}) {
		print $handle "$type_key\n" 
		    if $self->{'INFO'}{$type_key};
		foreach $data_key (keys %{$self->{'INFO'}{$type_key}}) {
			next if (($data_key eq "TIMER-ON") ||
 			         ($data_key eq "TIMER-OFF") ||
				 !$self->{'INFO'}{$type_key}{$data_key}); 
			printf $handle ("    %-20s \t %s\n", $data_key, 
					$self->{'INFO'}{$type_key}{$data_key});
		}
	}
	print $handle "\n";
}


#######################################
## subs that store info
#######################################
sub current {
	my $self = shift;
 	my %params = @_;
	my $name = $params{'-name'};
	my $append = $params{'-append'};
	my $org_name = $name;

	return if (!$self->{'DO-LOGGING'});

	if ($append) {
		if (!$self->{'TAKEN'}{$name}) {
			$self->{'CURRENT'} = $name;
			$self->{'INFO'}{$name} = ();
			$self->{'TAKEN'}{$name} = 1	
		}

	} else {
		if ($self->{'TAKEN'}{$name}) {
			my $cnt = 1;
			$name = $org_name .".". $cnt;
			while ($self->{'TAKEN'}{$name}) {
				$cnt++;
				$name = $org_name .".". $cnt;
			}
		}
		$self->{'CURRENT'} = $name;
		$self->{'INFO'}{$name} = ();
		$self->{'TAKEN'}{$name} = 1;
	}
}

sub saveCurrentInfo {
	my $self = shift;
	my %params = @_;
	my $type = $params{'-type'} || "DEFAULT";
	my $info = $params{'-info'};

	return if (!$self->{'DO-LOGGING'});

	$info = " : " . $info if
	    $self->{'INFO'}{$self->{'CURRENT'}}{$type};
	$self->{'INFO'}{$self->{'CURRENT'}}{$type} .= $info;
}


sub saveErrorsCurrent {
	my $self = shift;
	my %params = @_;
	my $error = $params{'-error'};

	return if (!$self->{'DO-LOGGING'});

	$error = " : " . $error if
	    $self->{'INFO'}{$self->{'CURRENT'}}{'ERRORS'};
	$self->{'INFO'}{$self->{'CURRENT'}}{'ERRORS'} .= $error;
}

# note this is not the same as increment
sub currentIncrement {
	my $self = shift;
	my %params = @_;
	my $name = $params{'-name'};

	return if (!$self->{'DO-LOGGING'});

	$self->{'INFO'}{$self->{'CURRENT'}}{$name}++;
}

sub currentLines {
	my $self = shift;
	my %params = @_;
	my $value = $params{'-value'};

	return if (!$self->{'DO-LOGGING'});

	if ($value =~ /^\d+$/) {
		$self->{'INFO'}{$self->{'CURRENT'}}{'LINES'} = $value;
	} else {
		$self->{'INFO'}{$self->{'CURRENT'}}{'LINES'} = $value =~ tr/\n/\n/;
	}
}

sub changeCurrent {
	my $self = shift;
	my %params = @_;
        my $name = $params{'-name'} || "DEFAULT";
        my $del_name = $params{'-del-name'};
	my $org_name = $name;

	return if (!$self->{'DO-LOGGING'});


        # used when you did not know the name of current untell after info was
        # placed in it
       	if ($self->{'CURRENT'} eq $del_name) {
		my %org_data = %{$self->{'INFO'}{$del_name}}
		                        if $self->{'INFO'}{$del_name};
		$self->{'INFO'}{$del_name}{'INFO'} = ();
		$self->{'TAKEN'}{$del_name} = 0;

		if ($self->{'TAKEN'}{$name}) {
			my $cnt = 1;
			$name = $org_name .".". $cnt;
			while ($self->{'TAKEN'}{$name}) {
				$cnt++;
				$name = $org_name .".". $cnt;
			}
		}

		$self->{'TAKEN'}{$name} = 1;
		%{$self->{'INFO'}{$name}} = %org_data;
		$self->{'CURRENT'} = $name;
	}
}

sub increment {
	my $self = shift;
	my %params = @_;
	my $name = $params{'-name'};

	return if (!$self->{'DO-LOGGING'});

	$self->{'INFO'}{$name}{'INCREMENT'}++;
}


#######################################
## subs that deal with timers
#######################################
sub timerOnCurrent {
        my $self = shift;

	return if (!$self->{'DO-LOGGING'});

 	$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-ON'} = new Benchmark;
}

sub timerOffCurrent {
	my $self = shift;

	return if (!$self->{'DO-LOGGING'});

	$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-OFF'} = new Benchmark;

	&timerValueCurrent($self);
}

sub timerValueCurrent {
	my $self = shift;

	return if (!$self->{'DO-LOGGING'});

	if (($self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-ON'}) &&
	    ($self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-OFF'})) {

		my($td) = timediff($self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-OFF'}, 
		    	           $self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-ON'});
		$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-VALUE'} = timestr($td);
	} else {
		$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-VALUE'} = "Does not exist";
	}

	$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-ON'} = ();
	$self->{'INFO'}{$self->{'CURRENT'}}{'TIMER-OFF'} = ();
}

#######################################
## subs that deal with the SIG alarm
#######################################
sub haltOn {
	my $self = shift;
	my $time = shift; 
	my $pid = shift;
	$self->{'PID'} = $pid;
	alarm($time);
}

sub haltOff {
	my $self = shift;
	alarm(0);
}

sub savedPid {
	my $self = shift;
	return $self->{'PID'};
}


1;



