#
#  file: edgar-date.pl
#  desc: EDGAR date manipulation routines
#
##########################################################################
#  Copyright (c) 1994, 1995 Internet Multicasting Service
#
#  The SEC EDGAR Level 1 Dissemination processing software ("software")
#  was developed by the Internet Multicasting Service and may 
#  be used for academic, research, government, and internal business
#  purposes without charge.  You may not resell this code or include it
#  in a product that you are selling without prior permission of the
#  Internet Multicasting Service.
#
#  This software is provided ``as is'', without express or implied
#  warranty, and with no support nor obligation to assist in its
#  use, correction, modification or enhancement.  We assume no liability
#  with respect to the infringement of copyrights, trade secrets, or any
#  patents, and are not responsible for consequential damages.  Proper
#  use of the software is entirely the responsibility of the user.
##########################################################################

package EDGAR::date;


# date manipulation info
@Months = ('', 'January', 'February', 'March', 'April', 'May', 'June',
           'July', 'August', 'September', 'October', 'November', 'December');
 
@days_in_month = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
 
#
# get date of EDGAR data file -- previous business day
#
sub edgar_date {
	local(@today) = localtime;

	if ($today[6] == 1) {    # 1 == Monday, so roll back to Friday
		$today[3] -= 3;
	} else {
		$today[3]--;
	}
 
	if ($today[3] <= 0) {
		if (--$today[4] < 0) {
			$today[4] = 11;    # 11 == December
		}
		# $today[3] is <= 0...
		$today[3] = $days_in_month[$today[4]] + $today[3];
	}

	# return modified date info
	@today;
}

# keep require happy
1;

=head1 NAME

edgar-date.pl - EDGAR date routines

=head1 PACKAGE

EDGAR::date

=head1 SYNOPSIS

require edgar-date.pl;

=head1 REQUIRES

Perl, version 5.001 or higher.

=head1 DESCRIPTION

EDGAR date routines. 

=over 3

=head1 METHODS

=head2 edgar_date

=item *

obtains date of EDGAR data file, which is the previous business day.

=item *

An array of date information is returned.

=item example:

my (@modifiedDate) = &EDGAR::date::edgar_date();

=back

=cut
