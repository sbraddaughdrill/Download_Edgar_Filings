#
#  file: edgar-parse.pl
#  desc: parsed EDGAR support
#


package EDGAR::Parse;

BEGIN {
	my $iw_root = ($ENV{IW}) ? $ENV{IW} : "/iw";
	my $edgar_root = "$iw_root/skulker/edgar/current";

	# where we find our local libraries
	my($libdir) = "$edgar_root/lib";
	if ( -d $libdir) {
		unshift(@INC, $libdir);
	}

	# parsed edgar forms support
	require 'edgar-forms.pl';

	# parsed edgar table support
	require 'edgar-table.pl';
}


# keep require happy
1;

